############# 1 ###########
### a part ###
data <- matrix(c(12, 50, 90, 150, 80, 63, 5, 10, 63, 63, 15, 8, 67, 56, 22, 19, 56, 63, 33, 19), nrow = 10, ncol = 2, byrow = TRUE)
county <- 1:10

jeffreys_credible_interval <- function(successes, failures) {
  total <- successes + failures
  
  beta_lower <- qbeta(0.025, successes + 0.5, failures + 0.5)
  beta_upper <- qbeta(0.975, successes + 0.5, failures + 0.5)
  return(c(beta_lower , beta_upper * total))
}

for (i in 1:nrow(data)) {
  successes <- data[i, 1]
  failures <- data[i, 2]
  credible_interval <- jeffreys_credible_interval(successes, failures)
  cat("County", country[i], ":\n")
  cat("Posterior 95% Credible Interval: (", credible_interval[1], ", ", credible_interval[2], ")\n\n")
}

### b part ###

sample_proportions <- c(12/(12 + 50), 90/(90 + 150), 80/(80 + 63), 5/(5 + 10), 63/(63 + 63), 15/(15 + 8), 67/(67 + 56), 22/(22 + 19), 56/(56 + 63), 33/(33 + 19))

#sample proportions
sample_mean <- mean(sample_proportions)
sample_variance <- var(sample_proportions)

# Solve for a and b
a <- sample_mean * ((sample_mean * (1 - sample_mean)) / sample_variance - 1)
b <- (1 - sample_mean) * ((sample_mean * (1 - sample_mean)) / sample_variance - 1)

cat("a =", a, "\n")
cat("b =", b, "\n")

### c part ####
empirical_credible_int <- function(successes, failures, a ,b){
  total <- successes + failures
  
  beta_lower <- qbeta(0.025, successes + a, failures + b)
  beta_upper <- qbeta(0.975, successes + a, failures + b)
  return(c(beta_lower * total, beta_upper * total)) 
}

posterior_credible_sets <- list()

for (i in 1:nrow(data)) {
  successes <- data[i, 1]
  failures <- data[i, 2]
  
  credible_interval <- empirical_credible_int(successes, failures, a, b)
  posterior_credible_sets[[paste0("County", country[i])]] <- credible_interval
  
  cat("County", country[i], ":\n")
  cat("Posterior 95% Credible Interval: (", credible_interval[1], ", ", credible_interval[2], ")\n\n")
}

############## 2 ###########

####(c) part
sigma_squared <- c(9,9,100)
Y_values <- c(12, 10,22)
posterior_variance <- 1/sum(1/(sigma_squared))
posterior_mean <- sum(Y_values/(sigma_squared)) * posterior_variance

posterior_distribution <- function(mu){
  mu * dnorm(mu, mean=posterior_mean, sd=sqrt(posterior_variance))
}

posterior_mean_numerical <- integrate(posterior_distribution, -Inf, +Inf)$value
posterior_mean_numerical

#### (d)

# Calculate MAP estimate (same as previous solution)
mu_MAP = (Y_values[1] / sigma_squared[1] + Y_values[2] / sigma_squared[2] + Y_values[3] / sigma_squared[3]) / 
  (1 / sigma_squared[1] + 1 / sigma_squared[2] + 1 / sigma_squared[3])

mu_values <- seq(-50, 50, length.out = 100)  # Adjust range as needed

# Calculate posterior density values
posterior_densities <- posterior_distribution(mu_values)

plot(mu_values, posterior_densities, type = "l", col = "blue", 
     main = "Posterior Distribution of µ", xlab = "µ", ylab = "Density")

abline(v = mu_MAP, lty = 2, col = "red", label = "MAP Estimate")
abline(v = posterior_mean, lty = 2, col = "green", label = "Posterior Mean")

legend("topright", legend = c("Posterior Distribution", "MAP Estimate", "Posterior Mean"),
       col = c("blue", "red", "green"), lty = c(1, 2, 2))

################### 3 ################

##(c)
library(MCMCpack)
# Updating sigma2
sigma2.update <- function(y,a,b)
{
  out <- rinvgamma(1,shape = a + 0.5,scale = 0.5*y^2 + b)
  return(out)
}

# updating b
b.update <- function(y,sigma2)
{
  out <- rexp(1,rate = (sum(1/sigma2)) + 1)
  return(out)
}

MCMC <- function(y,a,sigma2.init,b.init,iters)
{
  #chain initiation
  sigma2 <- sigma2.init
  b <- b.init
  
  # define chains
  sigma2.chain <- rep(NA,iters)
  b.chain <- rep(NA,iters)
  
  # start MCMC
  for(i in 1:iters)
  {
    sigma2 <- sigma2.update(y,a,b)
    b <- b.update(y,sigma2)
    
    sigma2.chain[i] <- sigma2
    b.chain[i] <- b
  }
  
  # return chains
  out <- list(sigma2.chain = sigma2.chain, b.chain = b.chain)
  return(out)
}

y <- 1:10
MCMC.out <- MCMC(y = y[1],a = 10,sigma2.init = var(y),b.init = 0,iters = 3e5)

plot(MCMC.out$sigma2.chain,xlab = "Iteration",ylab = "sigma2",type = "l")
abline(h = mean(MCMC.out$sigma2.chain),col = "red")

plot(MCMC.out$b.chain,xlab = "Iteration",ylab = "b",type = "l")
abline(h = mean(MCMC.out$b.chain),col = "red")

## (d)
## a = 1
y <- 1:10
MCMC.out <- MCMC(y = y[1],a = 1,sigma2.init = var(y),b.init = 0,iters = 3e5)

plot(MCMC.out$sigma2.chain,xlab = "Iteration",ylab = "sigma2",type = "l")
abline(h = mean(MCMC.out$sigma2.chain),col = "red")

plot(MCMC.out$b.chain,xlab = "Iteration",ylab = "b",type = "l")
abline(h = mean(MCMC.out$b.chain),col = "red")


########## 4 ###########
# Function to update parameters
update_parameters <- function(Y, n, m, q){
  param1 <- Y + exp(m) * q
  param2 <- n - Y + exp(m) * (1 - q)
  out <- rbeta(10, param1, param2)
  return(out)
}

# Function to calculate the log posterior of m
log_posterior_m <- function(m, theta, q){
  term_1 <- sum((exp(m) * q - 1) * log(theta))
  term_2 <- sum((exp(m) * (1 - q) - 1) * log((1 - theta)))
  term_3 <- m^2 / 20
  
  return(term_1 + term_2 - term_3)
}

# Function to update m
update_m <- function(m, theta, q, mh_m, acc_m){
  can_m <- rnorm(1, m, mh_m)
  R <- log_posterior_m(can_m, theta, q) - log_posterior_m(m, theta, q)
  
  if(log(runif(1)) < R){
    m <- can_m
    acc_m <- acc_m + 1
  }
  
  return(list(m = m, acc_m = acc_m))
}

# MCMC function
MCMC_Q4 <- function(Y,
                    theta_init = NULL, m_init = NULL,
                    n, q,
                    iters = 4e3, burn_in = 2e3){
  
  # Initial values
  theta <- theta_init
  m <- m_init
  mh_m <- 1
  acc_m <- 0
  
  # Storage
  keepers_theta <- matrix(NA, nrow = iters, ncol = 10)
  keepers_m <- rep(NA, iters)
  
  # MCMC loop starts
  for(i in 1:iters){
    theta <- update_parameters(Y, n, m, q)
    m_details <- update_m(m, theta, q, mh_m, acc_m)
    m <- m_details$m
    acc_m <- m_details$acc_m
    
    keepers_theta[i,] <- theta
    keepers_m[i] <- m
    
    print(paste0('Iterations : ',i))
  }
  return.iters <- (burn_in + 1):iters
  output <- list(theta = keepers_theta[return.iters, ],
                 m = keepers_m[return.iters],
                 acceptance_prob = acc_m / iters)
}

# Data
observed_Y <- c(64, 72, 55, 27, 75, 24, 28, 66, 40, 13)
observed_n <- c(75, 95, 63, 39, 83, 26, 41, 82, 54, 16)
observed_q <- c(0.845, 0.847, 0.88, 0.674, 0.909, 0.898, 0.77, 0.801, 0.802, 0.875)

# Run MCMC
MCMC_output_Q4 <- MCMC_Q4(Y = observed_Y,
                          theta_init = observed_Y / observed_n,
                          m_init = rnorm(1),
                          n = observed_n, q = observed_q,
                          iters = 1e4, burn_in = 2e3)

# Plot MCMC chains
for(i in 1:10){
  plot(MCMC_output_Q4$theta[,i], type = 'l',
       main = paste0('MCMC chain for theta_',i),
       ylab = paste0('theta_', i))
}
plot(MCMC_output_Q4$m, type = 'l',
     main = 'MCMC chain for m',
     ylab = 'm')

# Function to compute credible intervals
cred_interval_fn <- function(x){
  return(c(quantile(x, c(0.025, 0.975))))
}

# Compute credible intervals
cred_interval_theta <- t(apply(MCMC_output_Q4$theta, 2, cred_interval_fn))
cred_interval_m <- cred_interval_fn(MCMC_output_Q4$m)

# Using JAGS
library(rjags)

data_Q4 <- list(Y = observed_Y, n = observed_n, q = observed_q, count = length(observed_Y))

model_string_Q4 <- textConnection("model{
                              
    # Likelihood
    for(i in 1:count){
    Y[i] ~ dbin(theta[i], n[i])
    } 
    
    # Priors
    for(i in 1:count){
      theta[i] ~ dbeta(exp(m) * q[i], exp(m) * (1 - q[i]))
    }
    
    m ~ dnorm(0, 1/10)
}")

inits_Q4 <- list(theta = observed_Y / observed_n, m = rnorm(1))
model_Q4 <- jags.model(model_string_Q4, data = data_Q4, inits = inits_Q4, quiet = TRUE)

# Burn-in
update(model_Q4, 2e3, progress.bar = 'none')

# Post burn-in samples
params_Q4 <- c('theta', 'm')
samples_Q4 <- coda.samples(model_Q4,
                           variable.names = params_Q4,
                           n.iter = 1e4, progress.bar = 'none')

summary(samples_Q4)
plot(samples_Q4)




############### 5 #############

library(MASS)
data(galaxies)
Y <- galaxies

# Define likelihood function
likelihood <- function(mu, sigma, y) {
  n <- length(y)
  log_likelihood <- -n * log(2 * sigma) - sum(abs(y - mu) / sigma)
  return(exp(log_likelihood))
}

# Define prior for sigma
prior_mu <- function(mu){
  return (1)
}

# Define prior for sigma
prior_sigma <- function(sigma) {
  if(sigma <= 0 | sigma > 100000) {
    return(0)
  } else {
    return(1)
  }
}

# Define posterior distribution
posterior <- function(mu, sigma, y) {
  return(likelihood(mu, sigma, y) * prior_sigma(sigma)*prior_mu(mu))
}

# MCMC sampling using Metropolis-Hastings algorithm 
n_samples <- 10000  
burn_in <- 1000      

theta_init <- c(mean(Y), 100)  # Initial guess for theta

# Metropolis-Hastings loop
theta_chain <- matrix(0, n_samples, 2)
accept_count <- 0
for (i in (burn_in + 1):n_samples) {
  # Propose new candidate
  mu <-  rnorm(1, mean = theta_init[1], 1)
  sigma <-  rnorm(1, mean = theta_init[2], 1)
  theta_prop <- c(mu, sigma)
  
  # Calculate acceptance probability
  alpha <- exp(posterior(mu, sigma, Y) - posterior(theta_init[1],theta_init[1],Y))
  u <- runif(1)
  
  if (u < alpha) {
    theta_init <- theta_prop
    accept_count <- accept_count + 1
  }
  
  # Store sample
  theta_chain[i, ] <- theta_init
}
par(mfrow=c(2,2))
plot(theta_chain[,1], theta_chain[,2], xlab="mu", ylab="sigma", main="Joint Posterior Distribution")

# Plot marginal posterior distributions
hist(theta_chain[,1], breaks=50, col="black", xlab="mu", main="Marginal Posterior Distribution of mu")
hist(theta_chain[,2], breaks=50, col="black", xlab="sigma", main="Marginal Posterior Distribution of sigma")

### b part ####
# Calculate posterior mean of theta
mu_mean <- mean(theta_chain[,1])
sigma_mean <- mean(theta_chain[,2])
theta_mean <- c(mu_mean, sigma_mean)

# Function to generate Laplace distributed samples
rLaplace <- function(n, mu, sigma) {
  u <- runif(n, 0, 1)
  ifelse(u <= 0.5, mu - sigma * log(2 * u), mu + sigma * log(2 * (1 - u)))
}

# Generate data points from Laplace distribution with posterior mean parameters
y_replicated <- rLaplace(length(Y), mu_mean, sigma_mean)


# Plot data and replicated values
plot(Y, type = "p", col = "black", pch = 16, ylim = range(c(Y, y_replicated)), 
     xlab = "Index", ylab = "Value", main = "Observed Data vs. Replicated Values")
lines(y_replicated, col = "blue", lty = 2)
legend("topright", legend = c("Observed Data", "Replicated Values"), 
       col = c("black", "blue"), pch = c(16, NA), lty = c(NA, 2))

######### c #########
y_star <- rLaplace(10000, mu_mean, sigma_mean) ## new samples 

# Plot ppd
hist(y_star, breaks = 30, prob = TRUE, col = "black", 
     main = "Posterior Predictive Distribution", xlab = "Y*")

ppd_mean <- mean(y_star)
ppd_variance <- var(y_star)

plugin_mean <- mu_mean
plugin_variance <- 2 * sigma_mean^2  # Variance of Laplace distribution = 2 * sigma^2

library(knitr)
distribution_data <- data.frame(
  Distribution = c("Posterior Predictive Distribution", "Plug-in Distribution from part (b)"),
  Mean = c(ppd_mean, plugin_mean),
  Variance = c(ppd_variance, plugin_variance)
)

knitr::kable(distribution_data, caption = "Comparison of Mean and Variance between Posterior Predictive Distribution and Plug-in Distribution")

##### 3 (e) ####
library(rjags)

Y <- 1:10
n <- length(Y)
a <- 10

model_string <- "
model {
    # Likelihood
    for (i in 1:n) {
        Y[i] ~ dnorm(0, sigma2[i])
    }

    # Priors
    for (i in 1:n) {
        sigma2[i] ~ dinvgamma(a, b)
    }
    b ~ dgamma(1, 1)
}"

# Initial values
inits <- list(sigma2 = rep(1, n), b = 1)

# Run JAGS
model <- jags.model(textConnection(model_string), data = list(Y = Y, n = n, a = a), inits = inits)
update(model, 1000)  # burn-in
samples <- coda.samples(model, variable.names = c("sigma2", "b"), n.iter = 5000)

summary(samples)
plot(samples)
