################ Question - 1 #############
## Que - 10

library(rjags)
Y <- c(64, 13, 33, 18, 30, 20)
T <- length(Y)
years <- 2010:2015

model_string <- "
model {
  for (t in 1:T) {
    Y[t] ~ dpois(lambda[t])
    lambda[t] <- exp(alpha + beta * t)
  }
  
  alpha ~ dnorm(0, 10^2)
  beta ~ dnorm(0, 10^2)
}
"

model <- jags.model(textConnection(model_string), data = list(Y = Y, T = T), n.chains = 2)

# Burn-in and sampling
update(model, 1000)
samples <- coda.samples(model, variable.names = c("alpha", "beta"), n.iter = 5000)

# Check convergence
gelman.diag(samples)
autocorr.diag(samples)
effectiveSize(samples)

summary(samples)
plot(samples)

# posterior samples
posterior_samples <- as.matrix(samples)

# Calculate posterior means and credible intervals for beta
posterior_beta <- posterior_samples[, "beta"]
posterior_beta_mean <- mean(posterior_beta)
credible_interval <- quantile(posterior_beta, c(0.025, 0.975))

if (credible_interval[1] > 0 || credible_interval[2] < 0) {
  cat("There is evidence that the rate of discovery is changing over time.\n")
} else {
  cat("There is no evidence that the rate of discovery is changing over time.\n")
}

############### Que - 11

log_likelihood <- function(Y, alpha, beta) {
  lambda_t <- exp(alpha + beta * (1:length(Y)))
  sum(Y * log(lambda_t) - lambda_t - log(factorial(Y)))
}

log_prior <- function(alpha, beta) {
  -0.5 * (alpha^2 / 100 + beta^2 / 100)
}

# Metropolis sampler
metropolis_sampler <- function(Y, n_iterations, initial_values, proposal_std) {
  alpha_current <- initial_values[1]
  beta_current <- initial_values[2]
  alpha_samples <- numeric(n_iterations)
  beta_samples <- numeric(n_iterations)
  accepted <- 0
  
  for (i in 1:n_iterations) {
    alpha_proposed <- rnorm(1, alpha_current, proposal_std)
    beta_proposed <- rnorm(1, beta_current, proposal_std)
    
    log_likelihood_current <- log_likelihood(Y, alpha_current, beta_current)
    log_likelihood_proposed <- log_likelihood(Y, alpha_proposed, beta_proposed)
    log_prior_current <- log_prior(alpha_current, beta_current)
    log_prior_proposed <- log_prior(alpha_proposed, beta_proposed)
    
    acceptance_ratio <- exp(log_likelihood_proposed + log_prior_proposed - log_likelihood_current - log_prior_current)
    
    if (runif(1) < acceptance_ratio) {
      alpha_current <- alpha_proposed
      beta_current <- beta_proposed
      accepted <- accepted + 1
    }
    
    alpha_samples[i] <- alpha_current
    beta_samples[i] <- beta_current
  }
  acceptance_rate <- accepted / n_iterations
  return(list(alpha_samples = alpha_samples, beta_samples = beta_samples, acceptance_rate = acceptance_rate))
}

Y <- c(64, 13, 33, 18, 30, 20)
initial_values <- c(0, 0)
proposal_std <- 0.1
n_iterations <- 10000

result <- metropolis_sampler(Y, n_iterations, initial_values, proposal_std)

# Plot trace plots
par(mfrow = c(2, 1))
plot(result$alpha_samples, type = "l", main = "Trace plot of alpha")
plot(result$beta_samples, type = "l", main = "Trace plot of beta")

# Print acceptance rate
cat("Acceptance rate:", result$acceptance_rate, "\n")


############## Question - 2 ###############

## b part

library(stats)
set.seed(123)
theta_true <- 4
n <- 30
B <- rbinom(n, 1, 0.5)
Y <- rnorm(n, B * theta_true, 1)

f <- function(y, theta){
  0.5 * dnorm(y_range, theta, 1) + 0.5 * dnorm(y_range, 0, 1)
}

# Plotting f(y|θ) for θ = {2, 4, 6}
y <- seq(-3, 10, by = 0.1)
plot(y, f(y, 2), type = "l", col = "red", ylim = c(0, 0.4), xlab = "y", ylab = "Density", main = "f(y|θ) for θ = {2, 4, 6}")
lines(y, f(y,4), col = "orange")
lines(y, f(y,6), col = "purple")
legend("topright", legend = c("θ = 2", "θ = 4", "θ = 6"), col = c("red", "orange", "purple"), lty = 1, cex = 0.8)

## c part

set.seed(123)
library(stats)
# Define the negative log-posterior function
nlp <- function(theta, Y) {
  like <- 0.5 * dnorm(Y, 0, 1) + 0.5 * dnorm(Y, theta, 1)
  prior <- dnorm(theta, 0, 10)
  neg_log_post <- -sum(log(like)) - log(prior)
  return(neg_log_post)
}

# Function to minimize (negative log-posterior)
neg_log_post_wrapper <- function(theta, Y) {
  nlp(theta, Y)
}

# Starting value for optimization
start_theta <- 1

# Run optimization with hessian = TRUE
opt_result <- optim(start_theta, neg_log_post_wrapper, Y = Y, method = "BFGS", hessian = TRUE)

# MAP estimate
map_est <- opt_result$par
cat("MAP estimator of theta is ",map_est,"\n")

# Compute the Hessian matrix
hessian <- opt_result$hessian

# Compute the covariance matrix
cov_matrix <- solve(hessian)

# Standard deviation
sd <- sqrt(diag(cov_matrix))
cat("Standard deviation is ",sd,"\n")



## d part
set.seed(123)
library(stats)

# Define the negative log-posterior function
nlp <- function(theta, Y, k) {
  like <- 0.5 * dnorm(Y, 0, 1) + 0.5 * dnorm(Y, theta, 1)
  prior <- dnorm(theta, 0, 10^k)
  neg_log_post <- -sum(log(like)) - log(prior)
  return(neg_log_post)
}

# Function to minimize (negative log-posterior)
neg_log_post_wrapper <- function(theta, Y, k) {
  nlp(theta, Y, k)
}

# Starting value for optimization
start_theta <- 1

# Set values of k
k_values <- c(0, 1, 2, 3)

# Plot colors
colors <- c("skyblue","skyblue3","blue","darkblue")

# Plot
plot(NULL, xlim = c(2, 10), ylim = c(0, 2), xlab = "theta", ylab = "Density", main = "Posterior Density of theta for Different k Values")
# Plot asymptotic normal distribution from part (c)
curve(dnorm(x, map_est, sd), col = "red", lwd = 1, add = TRUE, n = 1000, from = -10, to = 20, ylab = "", xlab = "")

map_est_k <- numeric(length(k_values))
sd_k <- numeric(length(k_values))

# Loop through k values
for (i in seq_along(k_values)) {
  
  # Run optimization with hessian = TRUE
  opt_result <- optim(start_theta, neg_log_post_wrapper, Y = Y, k = k_values[i], method = "BFGS", hessian = TRUE)
  
  # Compute the Hessian matrix
  hessian <- opt_result$hessian
  
  # Compute the covariance matrix
  cov_matrix <- solve(hessian)
  
  # Standard deviation
  sd_k[i] <- sqrt(diag(cov_matrix))
  
  # MAP estimate
  map_est_k[i] <- opt_result$par
  
  # Plot posterior density
  curve(dnorm(x, map_est_k[i], sd_k[i]), col = colors[i],lty = c(4,3,2,1),lwd = 1, add = TRUE, n = 1000)
  
}
# Add legend for k_values
legend("topright", legend = paste("k =", k_values), col = colors, lty = c(4,3,2,1),lwd = 2, inset = 0.02)
# Add legend for the asymptotic normal distribution
legend("topleft", legend = "Asymptotic Normal", col = "red", lwd = 2, inset = 0.02)

data <- data.frame(k_values = k_values, map_est_k = map_est_k, sd_k = sd_k)
data

## e part
library(rjags)

# Data
data <- list(Y = Y, n = length(Y))

# Model string
model_string <- "
model {
  for (i in 1:n) {
    Y[i] ~ dnorm(theta * B[i], 1)
    B[i] ~ dbern(0.5)
  }
  theta ~ dnorm(0, 10^2)
}
"

# Compile the model
model <- jags.model(textConnection(model_string), data = data, n.chains = 2)

# Burn-in and sampling
update(model, 1000)
samples <- coda.samples(model, variable.names = c("theta"), n.iter = 5000)

# Posterior summary
summary(samples)

# Plot posterior distribution of theta
plot(samples)

# Extract posterior samples of theta from JAGS
theta_samples_jags <- as.matrix(samples)

# Plot the posterior distributions of theta from JAGS
plot(density(theta_samples_jags[, "theta"]), main = "Posterior Distribution of theta (JAGS)", xlab = "theta", col = "red", lwd = 2,ylim = c(0,2))
for (i in seq_along(k_values)) {
  curve(dnorm(x, map_est_k[i], sd_k[i]), col = colors[i], lty = c(4, 3, 2, 1), lwd = 2, add = TRUE, n = 1000)
}
legend("topright", legend = c("JAGS", paste("k =", k_values)), col = c("red", colors), lty = c(1, 4, 3, 2, 1), lwd = 2,inset=0.02)

############ Question - 3 ###############

## b part
data <- list(Y = 10)

# Model string with a = b = 1
model_string <- "
model {
  n ~ dpois(10)
  p ~ dbeta(1, 1)
  Y ~ dbin(p, n)
  theta <- n * p
}
"

model <- jags.model(textConnection(model_string), data = data, n.chains = 2)

# Burn-in and sampling
update(model, 1000)
samples <- coda.samples(model, variable.names = c("n", "p", "theta"), n.iter = 5000)

# Check convergence
gelman.diag(samples)
autocorr.diag(samples)
effectiveSize(samples)
summary(samples)

## c part
# Model string with a = b = 10
model_string <- "
model {
  n ~ dpois(10)
  p ~ dbeta(10, 10)
  Y ~ dbin(p, n)
  theta <- n * p
}
"
model <- jags.model(textConnection(model_string), data = data, n.chains = 2)

# Burn-in and sampling
update(model, 1000)
samples <- coda.samples(model, variable.names = c("n", "p", "theta"), n.iter = 5000)

gelman.diag(samples)
autocorr.diag(samples)
effectiveSize(samples)
summary(samples)



############# Question - 4 ############

set.seed(100)
## Placebo group
Y1 <- c(2.0,-3.1,-1.0,0.2,0.3,0.4)
ybar1 <- mean(Y1)
s1_square <- mean((Y1-ybar1)^2)
n1 <- length(Y1)

## Treatment group
Y2 <- c(-3.5,-1.6,-4.6,-0.9,-5.1,0.1)
ybar2 <- mean(Y2)
s2_square <- mean((Y2-ybar2)^2)
n2 <- length(Y2)

### Posterior (assuming equal variance)
diff <- ybar2 - ybar1
s2 <- (n1*s1_square + n2*s2_square)/(n1+n2)
scale <- sqrt(s2)*sqrt((1/n1)+(1/n2))
df <- n1 + n2
cred_interval_equal_variance <- diff + scale*qt(c(0.025,0.975),df = df)


# Posterior of delta assuming unequal variance using MC sampling
mu1 <- ybar1 + sqrt(s1_square/n1)*rt(1e3,df=n1)
mu2 <- ybar2 + sqrt(s2_square/n2)*rt(1e3,df=n2)
delta <- mu2-mu1
hist(delta,main="Posterior distribution of the difference in
means")
cred_interval_unequal_variance <- quantile(delta,c(0.025,0.975)) # 95% credible set

## print
cred_interval_equal_variance
cred_interval_unequal_variance


##As we can see  that the credible interval in both the case does not 
##contain zero, it suggests that there is a statistically significant difference between 
##the means of the placebo and treatment groups assuming equal variances and unequal variances. 

############# Question - 5 #############

##### a part
library(fda)
library(rjags)
Y <- Boston$medv
X <- cbind(1, Boston[-14])
head(X)
n <- nrow(X)  
p <- ncol(X)  

# center and scale covariates to have mean zero and variance one
X[ , 2:(p)] <- apply(X[ , 2:(p)], 2, scale)

data <- list(Y = Y, X = X, n = n, p = p)
params <- c("beta")
burn <- 10000
n.iter <- 20000
thin <- 10
n.chains <- 2

model_string <- textConnection("model{

for(i in 1:n){
Y[i] ~ dnorm(inprod(X[i,],beta[]), tau)
}
# Priors
beta[1] ~ dnorm(0, 0.0001)
for(j in 2:(p)){
beta[j] ~ dnorm(0,0.0001)
}
tau ~ dgamma(0.01, 0.01)
}")

model <- jags.model(model_string, data = data, n.chains = n.chains, quiet = TRUE)
update(model, burn, progress.bar = "none")
samples1 <- coda.samples(model, variable.names = params,
                         thin = thin, n.iter = n.iter, progress.bar = "none")
plot(samples1)
round(effectiveSize(samples1), 1)
summary(samples1)


#### b part

lm_model <- lm(medv ~ ., data = Boston)
lm_coefficients <- coef(lm_model)
lm_summary <- summary(lm_model)

# Print coefficients and summary
print(lm_coefficients)
print(lm_summary)

# Compare with Bayesian results
bayesian_summary <- summary(samples1)
print(bayesian_summary)


#### c part
model_string <- textConnection("model{
# Likelihood
for(i in 1:n){
Y[i] ~ dnorm(inprod(X[i,],beta[]), tau)
}
# Priors
beta[1] ~ dnorm(0, 0.0001)
for(j in 2:(p)){
beta[j] ~ ddexp(0, tau * taub)
}
tau ~ dgamma(0.01, 0.01)
taub ~ dgamma(0.01, 0.01)
}")
model <- jags.model(model_string, data = data, n.chains = n.chains, quiet = TRUE)
update(model, burn, progress.bar = "none")
samples2 <- coda.samples(model, variable.names = params,
                         thin = thin, n.iter = n.iter, progress.bar = "none")
plot(samples2)
round(effectiveSize(samples2), 1)
summary(samples2)

#### d part

# Define data
Y <- Boston$medv
X <- cbind(1, Boston[-14])
y_given <- Y[c(501:506)]
n <- 500
n_pred <- 6
X_pred <- X[501:506,]
y_pred <- rep(0,6)
data <- list(Y = Y, X = X, n = n, p = p, y_pred = y_pred, X_pred = X_pred, n_pred = n_pred)


# Model parameters
burn <- 10000
n.iter <- 20000
thin <- 10
n.chains <- 2

# Define JAGS model
model_string <- "
model {
  # Likelihood
  for (i in 1:n) {
    Y[i] ~ dnorm(inprod(X[i,], beta[]), taue)
  }
  
  # Priors
  beta[1] ~ dnorm(0, 0.0001)
  for (j in 2:p) {
    beta[j] ~ dnorm(0, taue * taub)
  }
  taue ~ dgamma(0.01, 0.01)
  taub ~ dgamma(1, 1)
  
  # Predictions
  for (i in 1:n_pred) {
    y_pred[i] ~ dnorm(inprod(X_pred[i,], beta[]), taue)
  }
}
"

# Compile JAGS model
model <- jags.model(textConnection(model_string), data = list(Y = Y, X = X, n = n, p = p, X_pred = X_pred, n_pred = n_pred), n.chains = n.chains, quiet = TRUE)

# Update and sample
update(model, burn)
samples <- coda.samples(model, variable.names = c("beta", "taue"), n.iter = n.iter, thin = thin)

beta_samples <- samples[[1]]
beta_samples <- as.matrix(beta_samples[,-15])
tau_samples <- samples[[1]]
tau_samples <- as.matrix(tau_samples[,15])


# Initialize matrix for predicted values
y_pred_samples <- matrix(NA, nrow = nrow(beta_samples), ncol = n_pred)

# Compute posterior predictive distribution
for (s in 1:nrow(beta_samples)) {
  for (i in 1:n_pred) {
    y_pred_samples[s, i] <- sum(X_pred[i, ] * beta_samples[s, ]) + rnorm(1, 0, sqrt(1 / tau_samples[s]))
  }
}

# Compute mean predicted values
y_pred_mean <- colMeans(y_pred_samples)

# Plot posterior predictive distribution versus actual values
plot(1:n_pred, y_pred_mean, type = "l", pch = 16, col = "red", xlab = "Index", ylab = "medv", ylim = c(10, 30))
lines(1:n_pred, y_given, col = "blue")
legend("topleft", legend = c("Y_pred", "Y_given"), col = c("red", "blue"), lty = 1)

