### 2 ###
## given
mu1 <- 1
mu2 <- 1.5
sigma <- 2
n <- 30
a <- 0.1 ## assumed
b <- 0.1
c <- 100

## generating data given mu1 and mu2
X <- rnorm(1e3, mean = mu1, sd = 2)
Y <- rnorm(1e3, mean = mu2, sd = 2)

posterior_dist <- function(mu_diff){
  shape <- n + a + 0.5
  rate <- 0.5*sum((X-mu1)^2 + (Y-mu2)^2) + 0.25*mu_diff^2/c + b
  constant <- b^a/(4*pi*sqrt(pi*c)*gamma(a))
  posterior <- gamma(shape)* constant / (rate^shape) 
}

mu_diff <- seq(-50,50 , length.out = 1000)
posterior_values <- sapply(mu_diff, posterior_dist)
plot(mu_diff, posterior_values )

### 3 ###
 
##given
lambda1 <- 2
lambda2 <- 2.5
n <- 15
m <- 10

X_data <- rpois(1e3, lambda1)
Y_data <- rpois(1e3, lambda2)

## assuming a and b
a <- 0.1
b <- 0.1
## assuming m = n
posterior <- rgamma(1e3,a+sum(X_data), b+m) / rgamma(1e3,2*a+sum(X_data + Y_data), b+n)
summary(posterior)

library(coda) ## library to calculate hpd interval

# Calculate the HPD credible interval
hpd_interval <- HPDinterval(as.mcmc(posterior), prob = 0.95)
hpd_interval

### 4 ###

#Question 4

n = 10
rho.true = 0.5

#data generation
X = numeric(length = n)

X[1] = rnorm(1)

for(i in 2:n){
  X[i] = rnorm(1, rho.true * X[i-1], sqrt(1-rho.true^2))
}

#drawing from posterior distribution
#taking U(-1,1) as proposal
AR_ratio = function(rho){
  (1-rho^2)^(-0.5*(n-1)) * exp( -0.5 * sum( (X[-1] - rho * X[-n])^2 ) / (1-rho^2))
} 
#taking a grid of rho
rho.grid = seq(-1+1e-2, 1-1e-2, 1e-3)

AR_rat_calc = sapply(rho.grid, AR_ratio)

c = max(AR_rat_calc)


B = 1e5
rho.sample = numeric(length = B)
count = 0
samp = 0
while(count < B){
  U = runif(1)
  prop = runif(1, -1, 1)
  
  if(U <= AR_ratio(prop)/c){
    rho.sample[count] = prop
    count = count + 1
    print(paste0('Accepted : ',count))
  }
  samp = samp + 1
}
# save(rho.sample, file = 'rho.sample.Rdata')
accept.rat = 1e5/samp

#kernel density plot of rho
library(ggplot2)
ggplot()+
  geom_density(aes(x = rho.sample, col = 'Posterior'), linewidth = 1)+
  geom_segment(aes(x = -1, y = 0.5, xend = 1, yend = 0.5, col = 'Prior'), linewidth = 1, linetype = 'dashed')+
  labs(x = expression(rho),
       y = 'Density',
       title = expression('Posterior Density of' ~ rho),
       col = "Index") +
  xlim(-1,1)



#drawing from posterior predictive distribution
X.ppd = matrix(NA, nrow = B, ncol = 2)

X.ppd[,1] = rnorm(B, rho.sample*X[n], sqrt(1 - rho.sample^2))
X.ppd[,2] = rnorm(B, rho.sample*X.ppd[,1], sqrt(1 - rho.sample^2))

#2D density plot of PPD
ggplot(as.data.frame(X.ppd), aes(V1, V2))+
  stat_density_2d_filled(aes(fill = after_stat(level)))+
  scale_color_viridis_c()+
  labs(x = 'X_T+1',
       y = 'X_T+2',
       title = 'Posterior Predictive Distribution of X_T+1, X_T+2 given X_1, ..., X_T')


### 5 ###
library(mvtnorm)
library(ggplot2)
mu <- c(0,0)
sigma <- matrix(c(1,0.5,0.5,1), nrow = 2)
B <- 1e5

samples <- rmvnorm(B, mean = mu, sigma = sigma)
head(samples)

samples <- as.data.frame(samples)
colnames(samples) <- c("X", "Y")
summary(samples)

### heatmap plot
 ggplot(samples, aes(x = X, y = Y)) +
  stat_density_2d(aes(fill = ..level..), geom = "polygon")  +
  scale_fill_viridis_c() +  
  labs(title = "2D Kernel Density Heatmap", x = "X", y = "Y") +
  theme_minimal() 

# parameters
B0 <- 10^3  
B <- 10^5  
mu <- c(0, 0)
sigma <- matrix(c(1, 0.5, 0.5, 4), nrow = 2) 


draw_samples <- function(B0, B, mu, sigma) {
  samples <- matrix(NA, nrow = B0 + B, ncol = 2)
  samples[1, ] <- c(0, 0)  # Initial samples
  
  for (b in 2:(B0 + B)) {
    samples[b, 1] <- rnorm(1, mean = mu[1] + sigma[1, 2]/sigma[2, 2] * (samples[b - 1, 2] - mu[2]), 
                           sd = sqrt(sigma[1, 1] - (sigma[1, 2]^2 / sigma[2, 2])))
    

    samples[b, 2] <- rnorm(1, mean = mu[2] + sigma[2, 1]/sigma[1, 1] * (samples[b, 1] - mu[1]), 
                           sd = sqrt(sigma[2, 2] - (sigma[2, 1]^2 / sigma[1, 1])))
  }
  
  return(samples)
}

samples_markov <- draw_samples(B0, B, mu, sigma)
head(samples_markov)

# Discard the first B0 samples
remaining_samples <- samples_markov[(B0 + 1):(B0 + B), ]
remaining_samples <- as.data.frame(remaining_samples)
colnames(remaining_samples) <- c("X", "Y")
summary(remaining_samples)

### heatmap plot
 ggplot(remaining_samples, aes(x = X, y = Y)) +
  stat_density_2d(aes(fill = ..level..), geom = "polygon")  +
  scale_fill_viridis_c() +  
  labs(title = "2D Kernel Density Heatmap", x = "X", y = "Y") +
  theme_minimal() 

 # Create histograms for X and Y separately for both sampling schemes
 hist_original_x <- hist(samples[, 1], breaks = 30, plot = FALSE)
 hist_original_y <- hist(samples[, 2], breaks = 30, plot = FALSE)
 hist_markov_x <- hist(remaining_samples[, 1], breaks = 30, plot = FALSE)
 hist_markov_y <- hist(remaining_samples[, 2], breaks = 30, plot = FALSE)
 
 # Create plots for histograms
 par(mfrow = c(2, 2))
 plot(hist_original_x, main = "Histogram of X (Original)", xlab = "X", ylab = "Frequency", col = "black")
 plot(hist_original_y, main = "Histogram of Y (Original)", xlab = "Y", ylab = "Frequency", col = "black")
 plot(hist_markov_x, main = "Histogram of X (Markov)", xlab = "X", ylab = "Frequency", col = "black")
 plot(hist_markov_y, main = "Histogram of Y (Markov)", xlab = "Y", ylab = "Frequency", col = "black")
 par(mfrow = c(1, 1))
 
